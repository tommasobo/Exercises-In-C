#include <stdio.h>
#include <stdlib.h>

int main()
{
	printf("Forza Cesena!\n");

	system("pause");
	return 0;
}