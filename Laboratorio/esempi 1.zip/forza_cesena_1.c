#include <stdio.h>

int main()
{
	printf("Forza Cesena!\n");

	return 0;
}